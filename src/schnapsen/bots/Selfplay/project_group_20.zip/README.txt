selfplay.ModelReader reads the exact path to the file. 
Run the selfplay file to start training.
You need pytorch to run this